﻿using System;
using System.IO;

namespace document
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Document\n");
            
            bool getDoc = true;
            while(getDoc)
            {
                string docName = getDocName();
                Console.WriteLine($"FileName: {docName}");

                string textFile = getText();
                newFile(docName, textFile);

                Console.WriteLine("Would you like to create another document? (y/n)");
                string another_doc = Console.ReadLine();
                if(another_doc != "y")
                {
                    getDoc = false;
                }
            }
        }

        //function responsible to get user's input 
        static string getDocName()
        {
            string name;
            while(true)
            {
                try
                {
                    Console.WriteLine("Enter the name of the document:"); 
                    name = Console.ReadLine();
                    if(name == "")
                    {
                        Console.WriteLine("Error: You must enter a document name");
                        continue;
                    }
                    break;
                }catch(Exception){
                    Console.WriteLine("Error: You entereed a invalid input.");
                }
            }
            
            return checkTxt(name);
        }

       //function to check if the file name ends with .txt
        static string checkTxt(string s)
        {
            //check to see if the name already ends with .txt
            if(s.EndsWith(".txt"))
            {
                return s;
            }
            //if it doesn't end with .txt -> add .txt
            else
            {
                return s + ".txt";
            }
        }

        static string getText()
        {
            string text;
            while(true)
            {
                try
                {
                    Console.WriteLine("Enter the content to be written in the document:");
                    text = Console.ReadLine();
                    if(text == null)
                    {
                        Console.WriteLine("Error: You must enter a text.");
                        continue;
                    }
                    break;
                }catch(Exception){
                    Console.WriteLine("Error: You entereed a invalid input.");
                }
            }
            return text;
        }

        //function that creates a new file and user input is added to it
        static void newFile(string s, string s2)
        {
            using (StreamWriter sw = File.AppendText(s))
            {
                try
                {
                    sw.WriteLine(s2);
                    
                }catch(Exception err){
                    Console.WriteLine($"Exception Occured: {err.Message}");
                }
                finally
                {
                    sw.Close();
                }
            }
        }
    }
}
