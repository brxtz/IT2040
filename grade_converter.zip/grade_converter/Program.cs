﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace grade_converter
{
    class Program
    {
        //function to pronpt user to enter grades and handle errors
        static float getGrades()
        {
            float userGrade;

            //handle errors
    
            try
            {
                //pompt the user for grade
                Console.WriteLine("Please enter the grade:");

                //get grade from console and convert to float type
                userGrade = float.Parse(Console.ReadLine());
            }catch(Exception){
                //if(userGrade < 0 || userGrade > 100)
                //{
                    Console.WriteLine("There was an error. Grade stored as -1");
                    //return -1 if bad input
                    userGrade = -1;
                //}
            }
            return userGrade;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your first and last name:  ");
            string firstLast = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine($"Hello {firstLast}! Welcome to the grade converter!\n");
            Console.WriteLine("How many grades would you like to enter?");
            int count = int.Parse(Console.ReadLine());
            //create a list of float
            List<float> grades = new List<float>();

            float userGrade;
            
            //add 3 numbers to my list based on users input
            for(int i = 0; i < count; i++)
            {
                userGrade = getGrades();
                grades.Add(userGrade);
            }


            float sum = 0;
            //print the values from the list
            Console.WriteLine();
            Console.WriteLine("Printing grades from list:");
            foreach(float item in grades)
            {
                Console.WriteLine($"Grade: {item}");
                Console.WriteLine();

                sum = sum + item;
            }

            //print letter grades
            Console.WriteLine("Printing letter grades:");
            foreach(float item in grades)
            {
                Console.WriteLine();

                if(item <= 100 && item >= 90)
                {
                   Console.WriteLine("Grade: A");
                }
                else if(item < 90 && item >= 80)
                {
                    Console.WriteLine("Grade: B");
                }         
                else if(item < 80 && item >= 70)
                {
                    Console.WriteLine("Grade: C");
                }
                else if(item < 70 && item >= 60)
                {
                    Console.WriteLine("Grade: D");
                }
                else if(item < 60 && item > 0)
                {
                    Console.WriteLine("Grade: F");
                }
                //else if(item < 0)
                //{
                    //Console.WriteLine("Looks like a grade was store as -1. Please enter a valid value.");
                    //grades.Remove(item)
                    //float newGrade = float.Parse(Console.ReadLine());
                    //grades.Add(newGrade);
                //}
                else{}
            }            

            //gets grade average 
            //float average = grades.Average(); 
            float average = sum / count;
            string averageLetter = "0";

            //gets letter grade for average 
            if(average <= 100 && average >= 90)
            {
                averageLetter  = "A";
            }
            else if(average < 90 && average >= 80)
            {
                averageLetter = "B";
            }         
            else if(average < 80 && average >= 70)
            {
                averageLetter = "C";
            }
            else if(average < 70 && average >= 60)
            {
                averageLetter = "D";
            }
            else if(average < 60 && average > 0)
            {
                averageLetter = "F";
            }
            else{}

            Console.WriteLine();
            Console.WriteLine("Grade Statistics");
            Console.WriteLine("-----------------");
            Console.WriteLine($"Number of grades: {count}");
            Console.WriteLine($"Average grade: {average}, which is a {averageLetter}");




        }

    }
}
