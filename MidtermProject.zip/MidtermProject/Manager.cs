using System;

namespace MidtermProject
{
    public class Manager : Employee
    {
        private string firstName, lastName, id, department, region;

        private EmployeeType empType;
        public Manager(string firstName, string lastName, string id, string department, string region) : base(firstName, lastName, id, EmployeeType.Manager)
        {
            this.department = department;
            this.region = region;
        }

        public void setDepartment(string newDepartment)
        {
            this.department = newDepartment;
        }

        public string getDepartment()
        {
            return this.department;
        }

        public void setRegion(string newRegion)
        {
            this.region = newRegion;
        }

        public string getRegion()
        {
            return this.region;
        }
    }
}