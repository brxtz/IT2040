using System;

namespace MidtermProject
{
    public class SalesPerson : Employee
    {
        private string firstName, lastName, id, department;
        private float sales;
        private EmployeeType empType;
        public SalesPerson(string firstName, string lastName, string id, string department, float sales) : base(firstName, lastName, id, EmployeeType.Sales)
        {
            this.department = department;
            this.sales = sales;
        }

        public float getSales()
        {
            return this.sales;
        }

        public float updateSales(float newSales)
        {
            this.sales += newSales;
            return this.sales;
        }
    
        public SalesLevel getSalesLevel()
        {

            if(this.sales >= 40000)
            {
                return SalesLevel.Platinum;
            }
            else if(this.sales >= 30000)
            {
                return SalesLevel.Diamond;
            }
            else if(this.sales >= 20000)
            {
                return SalesLevel.Gold;
            }
            else if(this.sales >= 10000)
            {
                return SalesLevel.Silver;
            }
            else
            {
                return SalesLevel.Bronze;
            }

        }    
    }


}