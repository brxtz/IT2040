using System;

namespace MidtermProject
{
    public class Employee
    {
        private string firstName, lastName, id;

        private EmployeeType empType;

        public Employee(string firstName, string lastName, string id, EmployeeType empType)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.id = id;
            this.empType = empType;
        }

        public void setFirstName(string newFirstName)
        {
            this.firstName = newFirstName;
        }

        public string getFirstName()
        {
            return this.firstName;
        }

        public void setLastName(string newLastName)
        {
            this.lastName = newLastName;
        }

        public string getLastName()
        {
            return this.lastName;
        }

        public void setEmpType(EmployeeType newEmpType)
        {
            this.empType = newEmpType;
        }

        public EmployeeType getEmpType()
        {
            return this.empType;
        }

        public string getId()
        {
            return this.id;
        }
        public void getEmployeeInfo()
        {
            Console.WriteLine($"Name: {this.firstName} {this.lastName}");
            Console.WriteLine($"ID: {this.id}");
            Console.WriteLine($"Type: {this.empType}");
        }   
    }
}