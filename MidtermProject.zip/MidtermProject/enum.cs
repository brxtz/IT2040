using System;

namespace MidtermProject
{
    public enum EmployeeType
    {
        Sales,
        Manager,
        Production
    }

    public enum SalesLevel
    {
        Platinum,
        Diamond,
        Gold,
        Silver,
        Bronze
    }
}