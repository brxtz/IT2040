using System;

namespace project_1
{
    class Employee
    {
        public string firstName, lastName;
        public int hoursWorked;
        public float salary, salaryTotal;

        public Employee(string firstName, string lastName, int hoursWorked, float salary)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.hoursWorked = hoursWorked;
            this.salary = salary;
            this.salaryTotal = totalSalary(hoursWorked, salary);
        }

        public float totalSalary(int hoursWorked, float salary)
        {
            return hoursWorked * salary;
        }
    }
}