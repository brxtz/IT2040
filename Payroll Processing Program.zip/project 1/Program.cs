﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace project_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string userName = getUserName();

            string fileName = getFileName();
            Console.Write("\n");
            Console.WriteLine($"Hello {userName}");
            Console.WriteLine("Welcome to the Payroll Processing Program\n------------------------------------------\n");

            List<float> fileInfo = readFile(fileName);

            Console.WriteLine();
            writeFile(fileInfo);

            
        }

        static string getUserName()
        {
            string userName;
            while(true)
            {
                try
                {
                    Console.WriteLine("Please enter your name:");
                    userName = Console.ReadLine();
                    if(userName == "")
                    {
                        Console.WriteLine("You must enter a name!\n");
                        continue;
                    }
                    break;
                }catch(Exception){
                    Console.WriteLine("An error occured.");
                }
            }
            return userName; 
        }

        static string getFileName()
        {
            string getFile;
            while(true)
            {
                try
                {
                    Console.WriteLine("Enter payroll file name to be processed:");    
                    getFile = Console.ReadLine();
                    getFile = checkCsv(getFile);
                    
                    if(getFile == "")
                    {
                        Console.WriteLine("You must enter a file name.\n");
                        continue;
                    }
                    
                    if(File.Exists(getFile))
                    {
                        Console.WriteLine("The file you entered exists!\n");
                    }
                    else
                    {
                        Console.WriteLine("The file you entered does not exists. Please enter a valid file name.\n");
                        continue;
                    }
                    break;   
                }catch(Exception err){
                    Console.WriteLine($"Error: {err.Message}");
                }
            }    
            return checkCsv(getFile);
        }

        static string checkCsv(string fileName)
        {
            if(fileName.EndsWith(".csv"))
            {
                return fileName;
            }
            else
            {
                return fileName + ".csv";
            }
        }

        static List<float> readFile(string fileName)
        {
            List<float> fileInfo = new List<float>();
            try
            {
                using (StreamReader sr = new StreamReader(fileName))
                {
                    while(!sr.EndOfStream)
                    {
                        string [] salaryData;
                        string lineOfData = sr.ReadLine();
                        salaryData = lineOfData.Split(",");

                        Employee employee = new Employee(salaryData[0], salaryData[1], int.Parse(salaryData[2]), float.Parse(salaryData[3]));
                        //string firstName = salaryData[0];
                        //string lastName = salaryData[1];
                        //int hoursWorked = int.Parse(salaryData[2]);
                        //float salary = float.Parse(salaryData[3]);

                        //float total = employee.hoursWorked * employee.salary;
                        Console.WriteLine($"{employee.firstName} {employee.lastName}: ${(employee.salaryTotal).ToString("0.00")}");

                        //fileInfo.InsertRange(4, firstName, lastName, total.ToString("0.00"));
                        fileInfo.Add(employee.salaryTotal);
                        //fileInfo.Add(total.ToString("0.00"));
                    }
                }
            }catch(Exception err){
                Console.WriteLine($"Error: {err.Message}");
            }
            return fileInfo;
        }

        static void writeFile(List<float> fileInfo)
        {   
            try
            {
                using (StreamWriter sw = new StreamWriter("SalarySummary.txt"))
                {
                    sw.Write("Salary Summary:\n---------------------------\n\n");
                    int count = fileInfo.Count;
                    sw.Write("Number of Employees Paid: {0}\n", count);


                    float totalSalary = 0;
                    for(int i = 0; i < count; i++)
                    {
                        totalSalary += fileInfo[i];
                    }
                    sw.Write("Total Salary Paid: {0:C2}\n", totalSalary);

                    float average = totalSalary / count;
                    sw.Write("Average Salary: {0:C2}\n", average);

                    sw.Write("Maximum Salary: {0:C2}\n", fileInfo.Max());
                    sw.Write("Minimum Salary: {0:C2}", fileInfo.Min());

                    Console.WriteLine("The file SalarySummary.txt was successfully created!\n");

                }
            }catch(Exception err){
                Console.WriteLine($"Error: {err.Message}");
            }

        }

    }
}
