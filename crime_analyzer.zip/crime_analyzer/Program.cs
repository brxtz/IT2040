﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace crime_analyzer
{
    class Program
    {
        static void Main(string[] args)
        {
            bool runProgram = true;
            while(runProgram)
            {
                if(args[0] == "" || args[1] == "")
                {
                    Console.WriteLine("CrimeAnalyzer <crime_csv_file_path> <report_file_path>");
                    break;
                }
                //get the user's command line arguments
                //Console.WriteLine($"Number of arguments provided: {args.Length}\n");
                string fileName = args[0];
                string reportName = args[1];

                string reportText = "";

                //create and load a list of crimes
                List<Crimes> crimesList = CrimesDataLoader.loadCrime(fileName);
                
                //process the crimes data in the list
                var maxYear = (from crimeStats in crimesList where (crimeStats.getYear() >= 1994 && crimeStats.getYear() <= 2013) select crimeStats.getYear()).Max();
                var minYear = (from crimeStats in crimesList where (crimeStats.getYear() >= 1994 && crimeStats.getYear() <= 2013) select crimeStats.getYear()).Min();
                reportText += $"Years range {minYear} - {maxYear} ({maxYear - minYear + 1} years)\n";

                var murderYears = from crimeStats in crimesList where crimeStats.getMurder() < 15000 select crimeStats.getYear();
                reportText += $"Years where number of murder is < 15000:\n";
                foreach(var years in murderYears)
                {
                    reportText += $"{years}\n";
                }

            
                var robberyAndYears = from crimeStats in crimesList where crimeStats.getRobbery() >= 50000 select crimeStats;
                reportText += "Years and associated robberies per year for years where the number of robberies is greater than 500000:\n";
                foreach(var crimeStats in robberyAndYears)
                {
                    reportText += $"{crimeStats.getYear()}: {crimeStats.getRobbery()}\n";
                }
            

                var violentCrime2010 = from crimeStats in crimesList where crimeStats.getYear() == 2010 select crimeStats.getViolentCrime();
                var population2010 = from crimeStats in crimesList where crimeStats.getYear() == 2010 select crimeStats.getPopulation();

                var allYearsMurderAvg = (from crimeStats in crimesList where (crimeStats.getYear() >= 1994 && crimeStats.getYear() <= 2013) select crimeStats.getMurder()).Average();
                reportText += $"\nAverage of murders (all years): {allYearsMurderAvg}";

                var avgMurder94_97 = (from crimeStats in crimesList where (crimeStats.getYear() >= 1994 && crimeStats.getYear() <= 1997) select crimeStats.getMurder()).Average();
                reportText += $"\nAverage of murders (1994-1997): {avgMurder94_97}";

                var avgMurder2010_2013 = (from crimeStats in crimesList where (crimeStats.getYear() >= 2010 && crimeStats.getYear() <= 2013) select crimeStats.getMurder()).Average();
                reportText += $"\nAverage of murders (2010-2013): {avgMurder2010_2013}";

                var minTheft99_04 = (from crimeStats in crimesList where (crimeStats.getYear() >= 1999 && crimeStats.getYear() <= 2004) select crimeStats.getTheft()).Min();
                reportText += $"\nMinimun number of thefts (1999-2004): {minTheft99_04}";

                var maxTheft99_04 = (from crimeStats in crimesList where (crimeStats.getYear() >= 1999 && crimeStats.getYear() <= 2004) select crimeStats.getTheft()).Max();
                reportText += $"\nMinimun number of thefts (1999-2004): {maxTheft99_04}";

                var maxMotorTheft = from crimeStats in crimesList where crimeStats.getMotorVehicleTheft() == (from crimeStats2 in crimesList where (crimeStats2.getYear() >= 1994 && crimeStats2.getYear() <= 2013) select crimeStats2.getMotorVehicleTheft()).Max() select crimeStats.getYear();
                foreach(var year in maxMotorTheft)
                {
                    reportText += $"\nYear with the highest number of motor vehicles theft: {year}";
                }

                //Write report text
                using(var reportWriter = new StreamWriter(reportName))
                {
                    reportWriter.Write(reportText);
                }
                
                Console.WriteLine("Would you like to run the program again? (y/n)");
                string runAgain = Console.ReadLine();
                if(runAgain != "y")
                {
                    runProgram = false;
                }
            }
        }
    }
}
