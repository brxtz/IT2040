using System;
using System.Collections.Generic;
using System.IO;

namespace crime_analyzer
{
    public class CrimesDataLoader
    {
        public static List<Crimes> loadCrime(string filePath)
        {
            List<Crimes> crimeList = new List<Crimes>();
            
            try
            {
                using (var crimeReader = new StreamReader("CrimeData.csv"))
                {
                    int lineNumber = 1;
                    int piecesOfData = 11;
                    string lineOfData = crimeReader.ReadLine();
                    //read file line by line
                    while(!crimeReader.EndOfStream)
                    {
                        lineNumber++;
                        string [] crimeData;
                        lineOfData = crimeReader.ReadLine();
                        crimeData = lineOfData.Split(",");
                        if(crimeData.Length != piecesOfData)
                        {
                            throw new Exception($"Row {lineNumber} contains {crimeData.Length} pieces if data. It should have {piecesOfData}");
                        }

                        //get individual values
                        try
                        {
                            int year = int.Parse(crimeData[0]);
                            int population = int.Parse(crimeData[1]);
                            int violentCrime = int.Parse(crimeData[2]);
                            int murder = int.Parse(crimeData[3]);
                            int rape = int.Parse(crimeData[4]);
                            int robbery = int.Parse(crimeData[5]);
                            int aggravatedAssault = int.Parse(crimeData[6]);
                            int propertyCrime = int.Parse(crimeData[7]);
                            int burglary = int.Parse(crimeData[8]);
                            int theft = int.Parse(crimeData[9]);
                            int motorVehicleTheft = int.Parse(crimeData[10]);
                            
                            Crimes crime = new Crimes(year, population, violentCrime, murder, rape, robbery, aggravatedAssault, propertyCrime, burglary, theft, motorVehicleTheft);

                            //add obj to tge list
                            crimeList.Add(crime);
                        }catch(Exception err){
                            throw new Exception($"Row {lineNumber} contains invalid data. {err.Message}");
                        }
                        //create new crimes object
                    }
                }
            }catch(Exception err){
                throw new Exception($"There was an error reading the file: {err.Message}");
            }

            return crimeList;
        }

    }
}