using System;

namespace Automobile
{
    public class Automobile
    {
        //private properties
        private string make, model, vin, color;

        private int year;
        private AutoType type;

        /*public enum AutoType
        {
            Sedan,
            Truck,
            Van,
            SUV
        }*/


        //constructor
        public Automobile(string make, string model, int year, string vin, string color, AutoType type)
        {     
            this.make = make;
            this.model = model;
            this.year = year;
            this.vin = vin;
            this.color = color;
            this.type = type;
        }

        //get and set methods
        public string getMake()
        {
            return this.make;
        }

        public string getModel()
        {
            return this.model;
        }

        public string getVin()
        {
            return this.vin;
        }

        public int getYear()
        {
            return this.year;
        }

        public AutoType getType()
        {
            return this.type;
        }

        public void setColor(string newColor)
        {
            this.color = newColor;
        }
        
        public string getColor()
        {
            return this.color;
        }
        public int getAutoAge()
        {
            int carAge = 2022 - this.year;
            return carAge;
        }

    }
}