using System;

namespace Automobile
{
    public enum AutoType
    {
        Sedan,
        Truck,
        Van,
        SUV
    }
}