﻿using System;
using System.Collections.Generic;

namespace ImprovedGradeConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string moreGrades;
            bool getInfo = true;
            
            while (getInfo)
            {
                string userName;
                userName = getName();
                
                Console.WriteLine();
                Console.WriteLine($"Hello {userName}! Welcome to the Grade Converter!\n");

                int count;
                count = counter();

                List<float> scores = new List<float>(); 
                scores = getGrades(count);
                
                Console.WriteLine();
                getLetterGrade(scores);

                getStats(count, scores);

                Console.WriteLine("Would you like to convert nore grades (y/n)?");
                moreGrades = Console.ReadLine();

                if(moreGrades != "y" && moreGrades != "Y")
                {
                    getInfo = false;
                }
            }

        }

        //function responsible for getting user's first and last name
        static string getName()
        {
            string userName;
            
            Console.WriteLine("{lease enter your first and last name:");
            
            userName = Console.ReadLine();
                   
            return userName;
        }

        //function responsible for getting the number of grades the user would like to enter 
        static int counter()
        {
            int counter;

            while(true)
            {
               Console.WriteLine("How many grades would you like to enter?");
                try
                {
                    counter = int.Parse(Console.ReadLine());
                    break;    
                }catch(FormatException){
                    Console.WriteLine("Error. Only whole numbers allowed."); 
                }
            }
            return counter;
        }

        //function that will create a list with the number of grades the user wants to enter
        static List<float> getGrades(int x)
        {
            float grade;
            List<float> scores = new List<float>();
            
            for(int i = 0; i < x; i++)
            {
                while(true)
                {
                    Console.WriteLine("\nEnter the grade:");
                    try{
                        grade = float.Parse(Console.ReadLine());
                        if(grade <= 0)
                        {      
                            Console.WriteLine("Error: Value must be 0 or greter.");
                            continue;
                        }
                        else if(grade > 100)
                        {
                            Console.WriteLine("Error: Value must be 100 or smaller");
                            continue;
                        }
                        break;      
                    }catch(FormatException){
                        Console.WriteLine("Error: Only numerical values allowed");
                    }
                }
                    scores.Add(grade);   
            }

            return scores;
        }

        //function responsible to get the letter grade equivalent to each grade entered
        static void getLetterGrade(List<float> y)
        {
            string letterGrade;
            foreach(float item in y)
            {
                //(A = 90-100, B = 80-89, C = 70-79, D = 60 - 69, F lower than 60).
                if (item >= 90){
                    letterGrade = "A";
                }else if(item >= 80){
                    letterGrade = "B";
                }else if (item >= 70){
                    letterGrade = "C";
                }else if(item >= 60){
                    letterGrade = "D";
                }else{
                    letterGrade = "F";
                }

                Console.WriteLine($"A score of {item} is a  {letterGrade}");
            }
        }

        //function that will return the average of the grades in the list
        static float getAverage(int x, List<float> y)
        {
            float totalScore = 0;

            foreach(float item in y)
            {
                totalScore += item;
            }

            return totalScore / x;
        }

        //function that will return the highest grade in the list
        static float getHighest(List<float> y)
        {
            for(int i = 1; i < y.Count; i++)
            {
                if(y[0] < y[i])
                {
                    y[0] = y[i];
                }
            }

            return y[0];
        }

        //function that will return the lowest grade in the list
        static float getLowest(List<float> y)
        {
            for(int i = 1; i < y.Count; i++)
            {
                if(y[0] > y[i])
                {
                    y[0] = y[i];
                }
            }

            return y[0];
        }


        //void funtion responsible for printing all the statistics
        static void getStats(int x,List<float> y)
        {
            Console.WriteLine("\nGrades Statistics");
            Console.WriteLine("---------------------");
            
            float average;
            average = getAverage(x, y);
            Console.WriteLine($"The grade average is {average}");

            float highest;
            highest = getHighest(y);
            Console.WriteLine($"The highest grade is {highest}");

            float lowest;
            lowest = getLowest(y);
            Console.WriteLine($"The lowest grade is {lowest}");
        }
    }
}
