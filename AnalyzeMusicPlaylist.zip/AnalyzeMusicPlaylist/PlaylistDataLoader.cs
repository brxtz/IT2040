using System;
using System.Collections.Generic;
using System.IO;

namespace AnalyzeMusicPlaylist
{
    public class PlaylistDataLoader
    {
        public static List<Musics> loadPlaylist(string filePath)
        {
            List<Musics> playlist = new List<Musics>();

            try
            {
                using (var musicReader = new StreamReader(filePath))
                {
                    int lineNumber = 1;
                    int piecesOfData = 8;
                    string lineOfData = musicReader.ReadLine();
                    //read file line by line
                    while(!musicReader.EndOfStream)
                    {
                        lineNumber++;
                        string [] musicData;
                        lineOfData = musicReader.ReadLine();
                        musicData = lineOfData.Split("\t");
                        if(musicData.Length != piecesOfData)
                        {
                            throw new Exception($"Row {lineNumber} contains {musicData.Length} pieces if data. It should have {piecesOfData}");
                        }

                        try
                        {
                            string name = musicData[0]; 
                            string artist = musicData [1];
                            string album = musicData [2];
                            string  genre = musicData [3];
                            int size = int.Parse(musicData[4]);
                            int time = int.Parse(musicData[5]); 
                            int year = int.Parse(musicData[6]); 
                            int plays = int.Parse(musicData[7]);
                        
                            Musics music = new Musics(name, artist, album, genre, size, time, year, plays);
                            
                            playlist.Add(music);
                        }catch(Exception err){
                            throw new Exception($"Row {lineNumber} contains invalid data. {err.Message}");
                        }

                    }
                }
            }catch(Exception err){
                throw new Exception($"There was an error reading the file: {err.Message}");
            }
            
            return playlist;
        }
    }
}