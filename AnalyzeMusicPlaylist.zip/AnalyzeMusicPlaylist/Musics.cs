using System;

namespace AnalyzeMusicPlaylist
{
    public class Musics
    {
        private string name, artist, album, genre;
        private int size, time, year, plays;

        public Musics(string name, string artist, string album, string genre, int size, int time, int year, int plays)
        {
            this.name = name;
            this.artist = artist;
            this.album = album;
            this.genre = genre;
            this.size = size;
            this.time = time;
            this.year = year;
            this.plays = plays;
        }

        public string getName() 
        {
            return this.name;
        }

        public string getArtist()
        {
            return this.artist;
        }

        public string getAlbum()
        {
            return this.album;
        }

        public string getGenre()
        {
            return this.genre;
        }

        public int getSize()
        {
            return this.size;
        }

        public int getTime()
        {
            return this.time;
        }

        public int getYear()
        {
            return this.year;
        }

        public int getPlays()
        {
            return this.plays;
        }
        
        override public string ToString()
        {
            return String.Format("Name: {0}, Artist: {1}, Album: {2}, Genre: {3}, Size: {4}, Time: {5}, Year: {6}, Plays: {7}", name, artist, album, genre, size, time, year, plays);
        } 
    }
}