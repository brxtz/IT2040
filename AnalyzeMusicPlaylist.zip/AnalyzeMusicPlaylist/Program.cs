﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AnalyzeMusicPlaylist
{
    class Program
    {
        static void Main(string[] args)
        {
            bool runProgram = true;
            while(runProgram)
            {
                if(args[0] == "" || args[1] == "")
                {
                    Console.WriteLine("CrimeAnalyzer <music_playlist_file_path> <report_file_path>");
                    break;
                }

                string filePath = args[0];
                string reportName = args[1];

                string reportText = "";

                //create and load playlist
                List<Musics> playlist = PlaylistDataLoader.loadPlaylist(filePath);

                //using LINQ query
                var plays = from music in playlist where music.getPlays() >= 200 select music;
                reportText += $"Number of songs that received 200 or more plays:\n";
                foreach(Musics music in plays)
                {
                    reportText += music + "\n";
                }

                var alternative = from music in playlist where music.getGenre() == "Alternative" select music;
                reportText += $"\nNumber of songs of Alternative genre: {alternative.Count()}\n";

                var rap = from music in playlist where music.getGenre() == "Hip-Hop/Rap" /* || music.getGenre() == "Hip Hop/Rap" || music.getGenre() == "Rap"*/ select music;
                reportText += $"\nNumber of songs of Hip-Hop/Rap genre: {rap.Count()}\n";

                var album = playlist.Where(music => (music.getAlbum() == "Welcome to the Fishbowl"));
                reportText += "\nSongs from the album 'Welcome from the Fishbowl': \n";
                foreach(Musics music in album)
                {
                    reportText += music + "\n";
                }

                var before1970 = playlist.Where(music => (music.getYear() < 1970));
                reportText += "\nSongs from before 1970:\n";
                foreach(Musics music in before1970)
                {
                    reportText += music + "\n";
                }

                var nameLenght = playlist.Where(music => (music.getName().Length > 85));
                reportText += $"\nSongs with names that are more than 85 characters long:\n";
                foreach(var music in nameLenght)
                {
                    reportText += $"Name: {music.getName()}\n";
                }

                var longestTime = playlist.Max(music => music.getTime());
                var longestMusic = (from music in playlist where music.getTime() == longestTime select music).ToList();
                reportText += "\nLongeste Song in the playlist:\n";
                foreach(var music in longestMusic)
                {
                    reportText += $"{music}\n";
                }

                var genres = from music in playlist 
                group music by music.getGenre() into genreGroup 
                orderby genreGroup.Key select genreGroup; 
                reportText += "\n**************\nUnique genres:\n";
                foreach(var genreGroup in genres)
                {
                    reportText += $"{genreGroup.Key}\n";
                }

                var yearlyMusics = from music in playlist
                group music by music.getYear() into yearlyGroup
                orderby  yearlyGroup.Key descending select yearlyGroup;
                reportText += "\n**************\nYearly number of songs in playlist:\n";
                foreach(var yearlyGroup in yearlyMusics)
                {
                    reportText += $"{yearlyGroup.Key}: {yearlyGroup.Count()}\n";
                }
                
                //plays per year
                int sum = 0;    
                reportText += "\n**************\nPlays per year:\n";
                foreach(var yearlyGroup in yearlyMusics)
                {
                   var playsPerYear = from music in playlist where music.getYear() == yearlyGroup.Key select music.getPlays();
                   foreach(var totalPlays in playsPerYear)
                   {
                       sum += totalPlays;
                   }
                   reportText += $"{yearlyGroup.Key}: {sum}\n";
                   sum = 0;
                }
                

    
                var uniqueArtist =(from music in playlist select music.getArtist()).Distinct();
                reportText += "\n**************\nUnique artists:\n";
                foreach(var artist in uniqueArtist)
                {
                    reportText += $"{artist}\n";
                }
                

                //writing report file
                using (var reportWriter = new StreamWriter(reportName))
                {
                    reportWriter.Write(reportText);
                }
                
                Console.WriteLine("Would you like to run the program again? (y/n)");
                string runAgain = Console.ReadLine();
                if(runAgain != "y")
                {
                    runProgram = false;
                }
            }
        }
    }
}
