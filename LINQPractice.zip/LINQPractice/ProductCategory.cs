using System;

namespace LINQPractice
{
    public enum ProductCategory
    {
        Computers,
        Electronics,
        Kitchen,
        Pet
    }
}